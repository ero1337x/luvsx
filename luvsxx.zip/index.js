const { Client, Intents, Collection, MessageEmbed } = require('discord.js');
const { clientId, guildId, botActivity, clientName, mutedRoleId, prefix } = require('./config.json');
const { errorEmoji } = require("./emojis.json")
const fs = require('node:fs');
const Fs = require('node:fs');
const ms = require("ms")
const { readdirSync } = require('fs');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const pogger = require("pogger");
const colors = require("colors");
const Enmap = require("enmap");
const db = require("quick.db");

const client = new Client({
  intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES], disableMentions: "everyone"
});

client.db = require("quick.db");

const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => res.send('<b>Host is Ready.</b><br><br>Use the link above to host your bot 24/7 on uptimerobot.com.'));

app.listen(port, () =>
	pogger.success(`[SERVER]`.bgCyan, `Server is Ready!`.green, ` App Listening to: https://localhost:${port}`.blue)
);

//
client.commands = new Collection();
const commands = [];
const commandFiles = fs.readdirSync('./slashCommands').filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
	const command = require(`./slashCommands/${file}`);
	commands.push(command.data.toJSON());
  client.commands.set(command.data.name, command);
}

const rest = new REST({ version: '9' }).setToken(process.env.TOKEN);

(async () => {
	try {
		pogger.warning('[SLASH-HANDLER]'.bgCyan,'Started refreshing application (/) commands...'.yellow);

		await rest.put(
			Routes.applicationGuildCommands(clientId, guildId),
			{ body: commands },
		);

		pogger.success('[SLASH-HANDLER]'.bgCyan,'Reloaded and Registered (/) Succesfully!'.green);
	} catch (error) {
		console.error(error);
	}
})();

client.on('interactionCreate', async interaction => {
	if (!interaction.isCommand()) return;

	const command = client.commands.get(interaction.commandName);

	if (!command) return;

	try {
		await command.execute(client, interaction);
	} catch (error) {
    const ConsoleIDErrorGen = Math.floor(Math.random() * 9999999) + 1;

		pogger.error(`[ERROR - ${ConsoleIDErrorGen}]`.bgRed, error);

    const embedErr = new MessageEmbed()
      .setTitle("Command Execution Failed.")
      .setDescription(`Unfortunality, **I can't Execute this Command!** The Error has been Logged on The Console.`)
      .addFields({ name: "Error ID:", value: `\`${ConsoleIDErrorGen}\``})
      .setColor("RED")
      .setFooter(`Please Contact the Developers to Report this Problem.`)
      .setTimestamp();

		await interaction.reply({ embeds: [embedErr], ephemeral: true });
	}
});

for(const file of readdirSync("./events")) {
    if(file.endsWith(".js")) {
        const content = require(`./events/${file}`)
        const key = file.substring(0, file.length - 3);

        client.on(key, content.bind(null, client));
    }
}

// WARNING: SNIPE COMMAND DOESN'T BREAKS DISCORD ToS. IF SOMEONE TOLD YOU THE OPPOSITE, YOU'VE BEEN SCAMMED.

client.snipes = new Map()

client.on('messageDelete', function(message, channel) {
  client.snipes.set(message.channel.id, {
    content: message.content,
    author: message.author.id,
    image: message.attachments.first() ? message.attachments.first().proxyURL : null
  })
})

client.on('messageCreate', async (message) => {
  if(message.content === `${prefix}snipe`){
    const { moderatorRoleId } = require("./config.json")
    const modRole = message.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
    return console.log("[WARN] The Mods role does not exist!");

    if (!message.member.roles.cache.has(modRole.id)) return message.reply({ content: `\`⛔\` **Missing Permissions:**\nYou are not allowed to use this command.`}).then(() => message.delete());
    const msg = client.snipes.get(message.channel.id)
    if(!msg) return message.reply({ content: `${errorEmoji} **No latest Deleted Message was Found.**` })

    const embed = new MessageEmbed()
      .setTitle("Snipe Command:")
      .setDescription(`**Channel:** <#${message.channel.id}>\n\n**User:** <@${msg.author}>\n\n**Message:** ${msg.content}`)
      .setColor("RED")
      .setFooter("WARNING: Snipe command Doesn't break Discord ToS.")
      .setTimestamp();

    if(msg.image) embed.setImage(msg.image)
    message.reply({ content: `<:snipemoment:949410093655556096> **Last Deleted Message:**`, embeds: [embed] })
  }
  
  if(message.content === `${prefix}t.f.a`){
    const messages = ["simps his crush", "is very gay", "loves women a lot", "is simp, not epik gaemer moment", "get pinged cringe", "a very funni person!!1!1!1!1!", "Fun Fact: ||ur mom||"]

    const randomMessage = messages[Math.floor(Math.random() * messages.length)];

    message.reply({content: `<@849413565487382578> ${randomMessage}`})
  }
})

client.login(process.env.TOKEN);