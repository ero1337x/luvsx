<p align="center"><img src = "https://images-ext-1.discordapp.net/external/1VhlONHVAMuboP0hko778EWrW-w6RqpX9eG3d5-mPAc/https/cdn.discordapp.com/avatars/849413565487382578/a_c18189704ae58280d2c3dd8df54f9c80.gif?width=115&height=115"></img></p>

##### By T.F.A#7524 - Coder's Paradise.
# Discord Moderation Bot with Slash Cmds Handler - [BETA]:
## 👋 Welcome to another T.F.A's Project! Here you can create a Discord Bot with Slash Commands *(Using Slash Handler)*! Here are the features:

### - Code's Advantages:
#### ✅ :- Create more Commands to improve your Bot.
#### ✅ :- Very Understandable Project and Can Understand very Fastly.
### - Code's Disavantages:
#### ❌ :- Some of the beginners don't understand the code, So they could mess their new project.
### - Code's Future Features:
#### ❔ :- More Moderation Commands.
# Let's Setup Your Bot!
### 🤖 Bot Setup:
#### Creating a new Client:
* `1-` Go to the Developer Portals by Clicking [Here!](https://discord.com/developers/applications)
* `2-` Click on `New Application`.
* `3-` Choose a name for your Bot, and then click on `Create`.
* `4-` Go to the **Bot** intersection, Click on `Add Bot` and Then `Yes`.
* `5-` A New Discord Bot has Appeared!
** **
### 📥 Invite The Bot:
* `1-` Go to the **OAuth2 > URL Generator** intersections.
* `2-` Select these both Scopes in **Scopes** case: `bot` | `application.commands`.
* `3-` Select for **Bot Permissions** case: `Administrator`
* `4-` Copy the Generated URL Below, It should be like this one: *https://discord.com/api/oauth2/authorize?client_id=**[YOUR_BOT_ID]**&permissions=8&scope=bot%20applications.commands.*
* `5-` Open a new Browser Tab, Paste the Link, Choose a server for your bot, Verify you are not a robot, and Done!
** **
### ⚙️ Configurations Setup:
> `Note:` If you Don't know how to get a Message, User, Channel or Server IDs, Go to **Account Settings > Advanced > Developer Mode** and make it Enabled (On).

* `1-` Right-click on the server icon and click on `Copy ID`. (Copy the Server ID that you Invited your bot there.)
* `2-` Go to now on `config.json`, set Your bot ID in the case "clientId" and the Server ID in the case "guildId".
* `3-` To get your bot ID, Right-click on your bot icon, and then click on `Copy ID`.

** **
### 🤫Bot Token Setup:
> `Important:` **Do not share your Bot Token. A Bot Token is a password like Discord Users, which anyone can access it without your permissions (If you shared it). So to keep everything safe and cool, and importantly Do not share your bot token. If your bot got hacked, It's gonna be your Fault.**

* `1-` Go to the **Bot** intersection on your Bot Developer Portal Site.
* `2-` Click on `Copy` to copy your bot token.
* `3-` Go to Replit, Click on the Lock icon (🔒)
* `4-` Set in **Key** case `TOKEN` and then paste your bot token in **Value** case.
* `5-` Bot is ready to use!
** **
### 🟢 Run the Bot and Make it online:
* Just click on the ***Run*** button above to Start your bot! *(Or go to Shell and type `node .`)*

> `Note:` If you are using Replit, create a new file called **.replit** and paste the code below:
```.replit
language: "nodejs"
run: "node ."
```
Just paste the code above in `.replit` file.

** **

### 🤔 Example and Simple Slash Command: [No Permissions Required]
```js
// Loads The Package for Slash Builder:
const { SlashCommandBuilder } = require('@discordjs/builders');

// Loads the Module:
module.exports = {
  // Creating a new Slash Command + Registering it:
	data: new SlashCommandBuilder()
    // Name of Slash Command:
		.setName('hello')
    // Description of Slash Command:
		.setDescription('Hello Command!'),
  // After loading the configurations of the new slash command, Now we can start our command development:
	async execute(client, interaction) {
    // This code below is replying to the user who used the command:
		await interaction.reply(`Hello! What's Up?`);
	},
};
```
### 🛡️ Advanced Slash Command for Moderation Commands: [Permissions Required]
```js
const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('ping')
		.setDescription('Replies with Pong!'),
	async execute(client, interaction) {

    const { moderatorRoleId } = require("../config.json")
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
    return console.log("[WARN] The Mods role does not exist!");

    if (!interaction.member.roles.cache.has(modRole.id)) { interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Moderator role to use this command! \n__**Required role:**__ <@&${modRole.id}>`, ephemeral: true })

    } else {
      //The entire code when the user is having the moderator role.
		  await interaction.reply(`Pong! ${client.ws.ping}ms`);

    }
	},
};
```

## ❤️ Simple Slash Commands Handler By: `T.F.A#7524`. Please while sharing this project, Give credits to me! (Or this will end in a Copyright warning. ©)