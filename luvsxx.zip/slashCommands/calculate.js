const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js")
const ms = module.require("ms")

module.exports = {
	data: new SlashCommandBuilder()
		.setName('calculate')
		.setDescription('Calculate something!')
    .addStringOption(option =>
		option.setName('type')
			.setDescription('Choose a Type of calculation:')
			.setRequired(true)
			.addChoice('addition', 'addition')
      .addChoice('subtraction', 'subtraction')
      .addChoice('multiplication', 'multiplication')
      .addChoice('division', 'division'))
    .addIntegerOption(option => option.setName('value_1').setDescription('Value 1 from calculation').setRequired(true))
    .addIntegerOption(option => option.setName('value_2').setDescription('Value 2 from calculation').setRequired(true)),
	async execute(client, interaction) {

    const { loadingEmoji, successEmoji } = require("../emojis.json")

		const type = interaction.options.getString('type');
    const value1 = interaction.options.getInteger('value_1');
    const value2 = interaction.options.getInteger('value_2');

    if(type === "addition") {

      interaction.reply({ content: `${loadingEmoji} **Calculating \`${value1}\` + \`${value2}\`...**`, ephemeral: true })
      
      const result = value1 + value2;

      const embed = new MessageEmbed()
        .setTitle("Calculator Results:")
        .setDescription(`${result || "MATH ERROR"}`)
        .setColor("BLURPLE")
        .setFooter("/calculator")
        .setTimestamp();

      interaction.channel.send({ embeds: [embed] })

    }

    if(type === "subtraction") {

      interaction.reply({ content: `${loadingEmoji} **Calculating \`${value1}\` - \`${value2}\`...**`, ephemeral: true })
      
      const result = value1 - value2;

      const embed = new MessageEmbed()
        .setTitle("Calculator Results:")
        .setDescription(`${result || "MATH ERROR"}`)
        .setColor("BLURPLE")
        .setFooter("/calculator")
        .setTimestamp();

      interaction.channel.send({ embeds: [embed] })

    }

    if(type === "multiplication") {

      interaction.reply({ content: `${loadingEmoji} **Calculating \`${value1}\` x \`${value2}\`...**`, ephemeral: true })
      
      const result = value1 * value2;

      const embed = new MessageEmbed()
        .setTitle("Calculator Results:")
        .setDescription(`${result || "MATH ERROR"}`)
        .setColor("BLURPLE")
        .setFooter("/calculator")
        .setTimestamp();

      interaction.channel.send({ embeds: [embed] })

    }

    if(type === "division") {

      interaction.reply({ content: `${loadingEmoji} **Calculating \`${value1}\` / \`${value2}\`...**`, ephemeral: true })

        const result = value1 / value2;

        if(value2 === 0) return interaction.channel.send("You can't divise a number by zero! I'm 200+ IQ")

        const embed = new MessageEmbed()
          .setTitle("Calculator Results:")
          .setDescription(`${result || "MATH ERROR"}`)
          .setColor("RED")
          .setFooter("/calculator")
          .setTimestamp();

        interaction.channel.send({ embeds: [embed] })
       

    }

    let time6 = "1s";
    setTimeout(function () {
      interaction.editReply(`${successEmoji} **Done!**`);
    }, ms(time6));

	},
};