const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js")
const { clientName } = require("../config.json")

module.exports = {
	data: new SlashCommandBuilder()
		.setName('say')
		.setDescription('Give me a message and I will say it with Embed or Normal!')
    .addStringOption(option =>
		option.setName('type')
			.setDescription('The Type of Say Message')
			.setRequired(true)
			.addChoice('Normal', 'Normal')
			.addChoice('Embed', 'Embed'))
    .addStringOption(option => option.setName('message').setDescription('Say something...').setRequired(true)),
	async execute(client, interaction) {
    const type = interaction.options.getString('type');
		const value = interaction.options.getString('message');

    if (type) {
      
    if (type === "Embed"){

        if (value) {

        const embed = new MessageEmbed()
          .setDescription(value)

        interaction.reply({ embeds: [embed] })
    
        }

    } else {
      if(type === "Normal"){

        if (value) {

          interaction.reply({ content: value })
    
        } else {

      const embedError2 = new MessageEmbed()
        .setTitle(`${client.user.name} - Say:`)
        .setDescription("You didn't specified a message!")
        .setColor("RED")

      interaction.reply({ embeds: [embedError2], ephemeral: true })

      }

      }
    }

    }
	},
};