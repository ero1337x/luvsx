const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed, MessageButton, MessageActionRow } = require("discord.js")

module.exports = {
	data: new SlashCommandBuilder()
		.setName('avatar')
		.setDescription('Get the avatar URL of the selected user, or your own avatar!')
		.addUserOption(option => option.setName('target').setDescription('The user\'s avatar to show').setRequired(true)),
	async execute(client, interaction) {

    const { successEmoji } = require("../emojis.json")

		const user = interaction.options.getUser('target');

    let embed1 = new MessageEmbed()
      .setTitle(`${user.username}'s Avatar:`)
      .setDescription(`\`•\` User: ${user} (${user.id})`)
      .setImage(user.displayAvatarURL({ dynamic: true }))
      .setColor("BLUE");

    const row = new MessageActionRow()
			.addComponents(
				new MessageButton()
					.setURL(`${user.displayAvatarURL()}`)
					.setLabel('Avatar URL')
          .setEmoji("929151502533136434")
					.setStyle('LINK'),
			);
    
    interaction.reply({ content: `${successEmoji} **Success!**`, embeds: [embed1], components: [row], ephemeral: true })
	},
};