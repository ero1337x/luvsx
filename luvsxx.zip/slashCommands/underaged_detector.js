const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js");

module.exports = {
	data: new SlashCommandBuilder()
		.setName('underaged_detector')
    .setDescription("Detect a random user if they are underaged or not")
    .addUserOption(option => option.setName('user').setDescription('The User to Warn.').setRequired(true)),
	async execute(client, interaction) {

    const { successEmoji } = require("../emojis.json")

      const target = interaction.options.getUser('user');

      const gen = Math.floor(Math.random() * 99) + 1;

      const embed = new MessageEmbed()
      .setTitle("Underaged Detector:")
      .setDescription(`🔞 ${target} is \`${gen}%\` Underaged!`)
      .setColor("RED")
      .setTimestamp();

		  await interaction.reply({ embeds: [embed] });
      
	},
};