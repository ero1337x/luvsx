const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js")
const { clientName } = require("../config.json")
const ms = module.require("ms")

module.exports = {
	data: new SlashCommandBuilder()
		.setName('embed_create')
		.setDescription('The Best Embed Creator Ever!')
    .addStringOption(option => option.setName('title').setDescription('Title of Embed').setRequired(true))
    .addStringOption(option => option.setName('description').setDescription('Description of Embed').setRequired(true))
    .addStringOption(option => option.setName('footer').setDescription('Footer of Embed'))
    .addStringOption(option => option.setName('color').setDescription('Color of Embed (Use RED, YELLOW, BLUE... etc)')),
	async execute(client, interaction) {

    const { moderatorRoleId } = require("../config.json")
    const { loadingEmoji, successEmoji } = require("../emojis.json")
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
    return console.log("[WARN] The Mods role does not exist!");

    if (!interaction.member.roles.cache.has(modRole.id)) return interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Moderator role to use this command! \n__**Required role:**__ <@&${modRole.id}>`, ephemeral: true });

    const title = interaction.options.getString('title');
    const description = interaction.options.getString('description');
    const footer = interaction.options.getString('footer');
    const color = interaction.options.getString('color');

    await interaction.reply({ content: `${loadingEmoji} **Creating new Embed Message...**`, ephemeral: true })

    const embed = new MessageEmbed()
      .setTitle(title || "")
      .setDescription(description || "")
      .setFooter(footer || "")
      .setColor(color || "BLURPLE")

    let time = "1s";
      setTimeout(function () {
        interaction.editReply({ content: `${successEmoji} **Success!**`});
        interaction.channel.send({ embeds: [embed] })
    }, ms(time));

    
	},
};