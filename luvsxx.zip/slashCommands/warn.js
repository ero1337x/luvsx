const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js")
const db = require("quick.db");

module.exports = {
	data: new SlashCommandBuilder()
		.setName('warn')
		.setDescription('Warn a User.')
    .addUserOption(option => option.setName('user').setDescription('The User to Warn.').setRequired(true))
    .addStringOption(option => option.setName('reason').setDescription('Reason of Warn.')),
	async execute(client, interaction) {

    const { moderatorRoleId } = require("../config.json")
    const { successEmoji } = require("../emojis.json")
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
    return console.log("[WARN] The Mods role does not exist!");

    if (!interaction.member.roles.cache.has(modRole.id)) { interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Moderator role to use this command! \n__**Required role:**__ <@&${modRole.id}>`, ephemeral: true })

    } else {

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    client.db.add(`Warnings_${interaction.guild.id}_${target.id}`, 1);

    let Warnings = client.db.get(
      `Warnings_${interaction.guild.id}_${target.id}`
    );
      
    let embed2 = new MessageEmbed()
      .setColor("YELLOW")
      .setDescription(`${target} has been **warned.** | \`${reason}\``);

    interaction.reply({ content: `${successEmoji} **Success!**`, ephemeral: true });

    interaction.channel.send({ embeds: [embed2] });
      

    }
	},
};