const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js")

module.exports = {
	data: new SlashCommandBuilder()
		.setName('ban')
		.setDescription('Ban a User.')
    .addUserOption(option => option.setName('user').setDescription('The User to Ban.').setRequired(true))
    .addStringOption(option => option.setName('reason').setDescription('Reason of Ban.').setRequired(true)),
	async execute(client, interaction) {

    const banUser = interaction.options.getUser('user');
    const banReason = interaction.options.getString('reason');

    const { moderatorRoleId } = require("../config.json")
    const { successEmoji } = require("../emojis.json")
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
    return console.log("[WARN] The Mods role does not exist!");

    if (!interaction.member.roles.cache.has(modRole.id)) return interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Moderator role to use this command! \n__**Required role:**__ <@&${modRole.id}>`, ephemeral: true });

    const embedBanSuccess = new MessageEmbed()
      .setDescription(`<@${banUser.id}> has been **banned.** | \`${banUser.id}\``)
      .setColor("RED");

    const embedBanSuccessWithReason = new MessageEmbed()
      .setDescription(`<@${banUser.id}> has been **banned.** | Reason: \`${banReason}\``)
      .setColor("RED");

    try {
        await interaction.guild.bans.create(banUser, {
            banReason
        })
  
        if(!banReason){
          interaction.reply({ content: `${successEmoji} **Successfully Banned ${banUser} \`(${banUser.id})\` from the Server!**`, ephemeral: true })
          await interaction.channel.send({ embeds: [embedBanSuccess] })
        } else {
          interaction.reply({ content: `${successEmoji} **Successfully Banned ${banUser} \`(${banUser.id})\` from the Server!**`, ephemeral: true })
          await interaction.channel.send({ embeds: [embedBanSuccessWithReason] })
        }
        
    }
    catch(err){
        if (err){
            console.error(err)
            const embedBanFail = new MessageEmbed()
              .setDescription(`Failed to Ban <@${banUser.id}>.`)
              .setFooter(`${err}`)
              .setColor("RED");
            return interaction.reply({ embeds: [embedBanFail], ephemeral: true })
        }
    }

  },
};