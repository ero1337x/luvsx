const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('dm')
		.setDescription('DM A user a message.')
    .addUserOption(option => option.setName('user').setDescription('The user to send the message.').setRequired(true))
    .addStringOption(option => option.setName('message').setDescription('The message').setRequired(true)),
	async execute(client, interaction) {

    const { moderatorRoleId } = require("../config.json")
    const { successEmoji, errorEmoji } = require("../emojis.json")
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
    return console.log("[WARN] The Mods role does not exist!");

    if (!interaction.member.roles.cache.has(modRole.id)) { interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Moderator role to use this command! \n__**Required role:**__ <@&${modRole.id}>`, ephemeral: true })

    } else {

    const target = interaction.options.getUser('user');
    const message = interaction.options.getString('message');

    if(target.bot) return interaction.reply({ content: `${errorEmoji} **I can't send a message to a bot in DMs due to an API Error!**`, ephemeral: true });

    const embed = new MessageEmbed()
      .setAuthor(`You've got a message from ${interaction.guild.name}:`)
      .addFields(
        { name: "Moderator:", value: `\`(Hidden)\``},
        { name: "Message:", value: `${message}`},
      )
      .setColor("BLUE")
      .setFooter("Thanks for Support!");
      
      target.send({ embeds: [embed] }).catch(() => interaction.channel.send({ content: `<@${interaction.member.id}>, \n${errorEmoji} **Can't send the message to that User.**\n\nPopular Reasons:\n\`•\` DMs Off.\n\`•\` User is a Bot. (Bots can't send messages to other Bots)`}));

      interaction.reply({ content: `${successEmoji} **Done!**`, ephemeral: true });

    }
	},
};