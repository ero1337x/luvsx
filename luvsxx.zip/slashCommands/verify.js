const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageActionRow, MessageButton, MessageEmbed } = require("discord.js");

module.exports = {
	data: new SlashCommandBuilder()
		.setName('verify')
		.setDescription('Verify yourself on the server!'),
	async execute(client, interaction) {

    const { verifiedRoleId } = require("../config.json")
    const { successEmoji, errorEmoji } = require("../emojis.json")
    const verifiedRole = interaction.guild.roles.cache.find(role => role.id === verifiedRoleId);

    if (!verifiedRole)
    return console.log("[WARN] The Verified role does not exist!");

    if (interaction.member.roles.cache.has(verifiedRole.id)) { interaction.reply({ content: `\`⛔\` **Permissions Denied:**\n\nYou are already Verified!`, ephemeral: true })

    } else {

      try {

        interaction.reply({ content: `${successEmoji} **You have been Verified Successfully!**`, ephemeral: true })
      
          const role = interaction.guild.roles.cache.get(verifiedRoleId)

          await interaction.member.roles.add(role)

      } catch (err){

      console.log(err)
      interaction.channel.send({ content: `${interaction.member},\n${errorEmoji} **An Error has Occured while Executing the Verify command.**\n\n**Error Reason:** \`${err}\``, ephemeral: true })
        
      }
    
      
    }
	},
};