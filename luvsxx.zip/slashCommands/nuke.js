const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js")

module.exports = {
	data: new SlashCommandBuilder()
		.setName('nuke')
		.setDescription('Nuke a Channel.')
    .addChannelOption(option => option.setName('channel').setDescription('WARNING: Deleting an Important channel like #rules, #news is not Allowed!').setRequired(true)),
	async execute(client, interaction) {

    const { adminRoleId } = require("../config.json")
    const { loadingEmoji, successEmoji } = require("../emojis.json")
    const adminRole = interaction.guild.roles.cache.find(role => role.id === adminRoleId);

    if (!adminRole)
    return console.log("[WARN] The Admin role does not exist!");

    if (!interaction.member.roles.cache.has(adminRole.id)) { interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Administrator role to use this command! \n__**Required role:**__ <@&${adminRole.id}>`, ephemeral: true })

    } else {
		  const channeltonuke = interaction.options.getChannel('channel');
			interaction.reply(`${loadingEmoji} **Nuking ${channeltonuke}...**`);
			const position = channeltonuke.position;
			const newChannel = await channeltonuke.clone();
			await channeltonuke.delete();
			newChannel.setPosition(position);
      
      const embed = new MessageEmbed()
        .setTitle("Channel Nuked!")
        .setDescription(`Nuked By: ${interaction.member} (${interaction.id})`)
        .setImage("https://media1.tenor.com/images/e275783c9a40b4551481a75a542cdc79/tenor.gif?itemid=3429833")
        .setColor("BLUE")
        .setTimestamp();

      await newChannel.send({ embeds: [embed] })

    }
	},
};