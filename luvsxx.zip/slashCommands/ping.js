const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('ping')
		.setDescription('Replies with Pong!'),
	async execute(client, interaction) {

    const { moderatorRoleId } = require("../config.json")
    const { successEmoji } = require("../emojis.json")
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
    return console.log("[WARN] The Mods role does not exist!");

    if (!interaction.member.roles.cache.has(modRole.id)) { interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Moderator role to use this command! \n__**Required role:**__ <@&${modRole.id}>`, ephemeral: true })

    } else {

      if(client.ws.ping <= 10) return interaction.reply(`${successEmoji} Pong! **${client.ws.ping}ms** \`(Super Good)\``);

      if(client.ws.ping >= 10) return interaction.reply(`${successEmoji} Pong! **${client.ws.ping}ms** \`(Very Good)\``);

      if(client.ws.ping >= 25) return interaction.reply(`${successEmoji} Pong! **${client.ws.ping}ms** \`(Good)\``);

      if(client.ws.ping >= 50) return interaction.reply(`${successEmoji} Pong! **${client.ws.ping}ms** \`(Not Bad)\``);

      if(client.ws.ping >= 75) return interaction.reply(`${successEmoji} Pong! **${client.ws.ping}ms** \`(Medium)\``);

      if(client.ws.ping >= 100) return interaction.reply(`${successEmoji} Pong! **${client.ws.ping}ms** \`(Bad)\``);

      if(client.ws.ping >= 150) return interaction.reply(`${successEmoji} Pong! **${client.ws.ping}ms** \`(Very Bad)\``);

    }
	},
};