const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js")
const ms = module.require("ms")

module.exports = {
	data: new SlashCommandBuilder()
		.setName('purge')
		.setDescription('Clear some Messages.')
    .addIntegerOption(option => option.setName('value').setDescription('Value to delete the Messages. (Do not delete messages older than 14 days!)').setRequired(true)),
	async execute(client, interaction) {
    const value = interaction.options.getInteger('value');

    const { moderatorRoleId } = require("../config.json")
    const { loadingEmoji, successEmoji, errorEmoji } = require("../emojis.json")
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
    return console.log("[WARN] The Mods role does not exist!");

    if (!interaction.member.roles.cache.has(modRole.id)) { interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Moderator role to use this command! \n__**Required role:**__ <@&${modRole.id}>`, ephemeral: true })

    } else {

      if(value > 100) return interaction.reply({ content: `${errorEmoji} **Can't Delete more than __\`100\`__ Messages!**`, ephemeral: true });

      if(value <= 3) return interaction.reply({ content: `${errorEmoji} **You can Delete __\`${value}\`__ Message(s) without Using this Command!**`, ephemeral: true });

      var deleteMsg = interaction.reply({ content: `${loadingEmoji} **Purging...**`, ephemeral: true });

      const embed = new MessageEmbed()
        .setDescription(`Successfully Deleted **${value}** messages on the Channel <#${interaction.channel.id}>. | \`${interaction.channel.id}\``)
      .setColor("GREEN");

      let time = "2s";
        setTimeout(function () {
        interaction.editReply(`${successEmoji} **Success!**`);
        interaction.channel.bulkDelete(value);
        interaction.channel.send({ embeds: [embed] })
      }, ms(time));
      
    }
	},
};