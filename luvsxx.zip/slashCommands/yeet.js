const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js");
const ms = module.require("ms");

module.exports = {
	data: new SlashCommandBuilder()
		.setName('yeet')
		.setDescription('Ban all members!!!11!1!11!1!!'),
	async execute(client, interaction) {

    const { moderatorRoleId } = require("../config.json")
    const { loadingEmoji, successEmoji } = require("../emojis.json")
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
    return console.log("[WARN] The Mods role does not exist!");

    if (!interaction.member.roles.cache.has(modRole.id)) { interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Moderator role to use this command! \n__**Required role:**__ <@&${modRole.id}>`, ephemeral: true })

    } else {

    let msg = await interaction.reply({ content: `${loadingEmoji} **Loading the Command...**` });

    const embed = new MessageEmbed()
      .setDescription(`Started to Ban **${interaction.guild.memberCount} Members**. Loading...`)
      .setColor("RED")

    const embed1 = new MessageEmbed()
      .setDescription(`TimeLapse: [**__⠄__**⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄] (\`2%\`)`)
      .setColor("RED")

    const embed2 = new MessageEmbed()
      .setDescription(`TimeLapse: [**__⠄⠄⠄__**⠄⠄⠄⠄⠄⠄⠄⠄⠄] (\`21%\`)`)
      .setColor("RED")

    const embed3 = new MessageEmbed()
      .setDescription(`TimeLapse: [**__⠄⠄⠄⠄⠄__**⠄⠄⠄⠄⠄⠄⠄] (\`37%\`)`)
      .setColor("RED")

    const embed4 = new MessageEmbed()
      .setDescription(`TimeLapse: [**__⠄⠄⠄⠄⠄⠄__**⠄⠄⠄⠄⠄⠄] (\`47%\`)`)
      .setColor("RED")

    const embed5 = new MessageEmbed()
      .setDescription(`TimeLapse: [**__⠄⠄⠄⠄⠄⠄⠄__**⠄⠄⠄⠄⠄] (\`61%\`)`)
      .setColor("RED")

    const embed6 = new MessageEmbed()
      .setDescription(`TimeLapse: [**__⠄⠄⠄⠄⠄⠄⠄⠄⠄__**⠄⠄⠄] (\`78%\`)`)
      .setColor("RED")

    const embed7 = new MessageEmbed()
      .setDescription(`TimeLapse: [**__⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄__**⠄] (\`98%\`)`)
      .setColor("RED")

    const embed8 = new MessageEmbed()
      .setDescription(`TimeLapse: [**__⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄__**] (\`99%\`)`)
      .setColor("RED")
      
    const embed9 = new MessageEmbed()
      .setDescription(`TimeLapse: [⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄] (\`Crashed\`)`)
      .setColor("BLACK")

    let time = "3s";
    setTimeout(function () {
      interaction.editReply({ content: `${successEmoji} **Success!**`, embeds: [embed] });
    }, ms(time));

    let time1 = "5s";
    setTimeout(function () {
      interaction.editReply({ content: `** **`, embeds: [embed1] });
    }, ms(time1));

    let time2 = "7s";
    setTimeout(function () {
      interaction.editReply({ content: `** **`, embeds: [embed2] });
    }, ms(time2));

    let time3 = "10s";
    setTimeout(function () {
      interaction.editReply({ content: `** **`, embeds: [embed3] });
    }, ms(time3));

    let time4 = "11s";
    setTimeout(function () {
      interaction.editReply({ content: `** **`, embeds: [embed4] });
    }, ms(time4));

    let time5 = "14s";
    setTimeout(function () {
      interaction.editReply({ content: `** **`, embeds: [embed5] });
    }, ms(time5));

    let time6 = "16s";
    setTimeout(function () {
      interaction.editReply({ content: `** **`, embeds: [embed6] });
    }, ms(time6));

    let time7 = "17s";
    setTimeout(function () {
      interaction.editReply({ content: `** **`, embeds: [embed7] });
    }, ms(time7));

    let time8 = "20s";
    setTimeout(function () {
      interaction.editReply({ content: `** **`, embeds: [embed8] });
    }, ms(time8));

    let time9 = "25s";
    setTimeout(function () {
      interaction.editReply({ content: `** **`, embeds: [embed9] });
      interaction.channel.send({ content: "I can't ban the owner, so the command has failed <a:troll_walking_moment:948953845671809104>"})
    }, ms(time9));


    }
	},
};