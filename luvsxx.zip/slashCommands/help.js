const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js")
const { clientName } = require("../config.json")

module.exports = {
	data: new SlashCommandBuilder()
		.setName('help')
		.setDescription('List of Commands!')
    .addStringOption(option =>
		option.setName('type')
			.setDescription('Choose a Type of Commands.')
			.setRequired(true)
			.addChoice('Moderation', 'Moderation')
      .addChoice('Images', 'Images')
      .addChoice('Informations', 'Informations')
      .addChoice('General', 'General')
      .addChoice('Utility', 'Utility')
			.addChoice('Fun', 'Fun')),
	async execute(client, interaction) {
    const type = interaction.options.getString('type');

    const { moderatorRoleId } = require("../config.json")
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
    return console.log("[WARN] The Mods role does not exist!");

    if (!interaction.member.roles.cache.has(modRole.id)) { interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Moderator role to use this command! \n__**Required role:**__ <@&${modRole.id}>`, ephemeral: true })

    } else {
    
    if(type === "Moderation"){
      const embed = new MessageEmbed()
        .setAuthor(`${clientName} - Moderation Commands:`)
        .setDescription("`ban`, `kick`, `nuke`, `purge`, `yeet`, `warn`, `delete_warns`, `warnings`, `dm`, `stop`.")
        .setColor("GREEN")
        .setFooter("Slash Commands - /help")
        .setTimestamp()

      const row = new MessageActionRow()
			.addComponents(
				new MessageButton()
					.setCustomId('primary')
					.setLabel(`Your Account ID: ${interaction.member.id}`)
          .setEmoji("933131741017800714")
					.setStyle('SUCCESS')
          .setDisabled(true),
			);

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true })
    }

    if(type === "Images"){
      const embed = new MessageEmbed()
        .setAuthor(`${clientName} - Images Commands:`)
        .setDescription("`avatar`.")
        .setColor("GREEN")
        .setFooter("Slash Commands - /help")
        .setTimestamp()

      const row = new MessageActionRow()
			.addComponents(
				new MessageButton()
					.setCustomId('primary')
					.setLabel(`Your Account ID: ${interaction.member.id}`)
          .setEmoji("933131741017800714")
					.setStyle('SUCCESS')
          .setDisabled(true),
			);

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true })
    }

    if(type === "Informations"){
      const embed = new MessageEmbed()
        .setAuthor(`${clientName} - Info Commands:`)
        .setDescription("`member_count`, `invite`.")
        .setColor("GREEN")
        .setFooter("Slash Commands - /help")
        .setTimestamp()

      const row = new MessageActionRow()
			.addComponents(
				new MessageButton()
					.setCustomId('primary')
					.setLabel(`Your Account ID: ${interaction.member.id}`)
          .setEmoji("933131741017800714")
					.setStyle('SUCCESS')
          .setDisabled(true),
			);

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true })
    }

    if(type === "General"){

      const embed = new MessageEmbed()
        .setAuthor(`${clientName} - General Commands:`)
        .setDescription("`ping`, `help`.")
        .setColor("GREEN")
        .setFooter("Slash Commands - /help")
        .setTimestamp()
      
      const row = new MessageActionRow()
			.addComponents(
				new MessageButton()
					.setCustomId('primary')
					.setLabel(`Your Account ID: ${interaction.member.id}`)
          .setEmoji("933131741017800714")
					.setStyle('SUCCESS')
          .setDisabled(true),
			);

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true })
    }

    if(type === "Utility"){
      const embed = new MessageEmbed()
        .setAuthor(`${clientName} - Utility Commands:`)
        .setDescription("`embed_create`, `calculate`, `verify`.")
        .setColor("GREEN")
        .setFooter("Slash Commands - /help")
        .setTimestamp()

      const row = new MessageActionRow()
			.addComponents(
				new MessageButton()
					.setCustomId('primary')
					.setLabel(`Your Account ID: ${interaction.member.id}`)
          .setEmoji("933131741017800714")
					.setStyle('SUCCESS')
          .setDisabled(true),
			);

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true })
    }

    if(type === "Fun"){
      const embed = new MessageEmbed()
        .setAuthor(`${clientName} - Fun Commands:`)
        .setDescription("`say`, `underaged_detector`.")
        .setColor("GREEN")
        .setFooter("Slash Commands - /help")
        .setTimestamp()

      const row = new MessageActionRow()
			.addComponents(
				new MessageButton()
					.setCustomId('primary')
					.setLabel(`Your Account ID: ${interaction.member.id}`)
          .setEmoji("933131741017800714")
					.setStyle('SUCCESS')
          .setDisabled(true),
			);

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true })
    }
    }
	},
};