const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js")

module.exports = {
	data: new SlashCommandBuilder()
		.setName('kick')
		.setDescription('Kick a User.')
    .addUserOption(option => option.setName('user').setDescription('The User to Kick.').setRequired(true))
    .addStringOption(option => option.setName('reason').setDescription('Reason of Kick.').setRequired(true)),
	async execute(client, interaction) {

    const kickUser = interaction.options.getUser('user');
    const kickReason = interaction.options.getString('reason');

    const { moderatorRoleId } = require("../config.json")
    const { successEmoji } = require("../emojis.json")
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
    return console.log("[WARN] The Mods role does not exist!");

    if (!interaction.member.roles.cache.has(modRole.id)) return interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Moderator role to use this command! \n__**Required role:**__ <@&${modRole.id}>`, ephemeral: true });

    const embedKickSuccess = new MessageEmbed()
      .setDescription(`<@${kickUser.id}> has been **kicked.** | \`${kickUser.id}\``)
      .setColor("RED");

    const embedKickSuccessWithReason = new MessageEmbed()
      .setDescription(`<@${kickUser.id}> has been **kicked.** | Reason: \`${kickReason}\``)
      .setColor("RED");

    const embedKickFail = new MessageEmbed()
      .setDescription(`Failed to Kick <@${kickUser.id}>.`)
      .setColor("RED");

    try {
        await interaction.guild.members.kick(kickUser, kickReason);

        if(!kickReason){
          
        interaction.reply({ content: `${successEmoji} **Successfully Kicked ${kickUser} \`(${kickUser.id})\` from the Server!**`, ephemeral: true })
  
        interaction.channel.send({ embeds: [embedKickSuccess] })

        } else {

        interaction.reply({ content: `${successEmoji} **Successfully Kicked ${kickUser} \`(${kickUser.id})\` from the Server!**`, ephemeral: true })

        interaction.channel.send({ embeds: [embedKickSuccessWithReason] })
          
        }

    }
    catch(err){
        if (err){
            console.error(err)
            return interaction.reply({ embeds: [embedKickFail], ephemeral: true })
        }
    }

  },
};