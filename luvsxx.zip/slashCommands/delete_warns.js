const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js")
const db = require("quick.db");
const ms = module.require("ms");

module.exports = {
	data: new SlashCommandBuilder()
		.setName('delete_warns')
		.setDescription('Delete the user warnings from DataBase.')
    .addUserOption(option => option.setName('user').setDescription('The User to Reset Warnings.').setRequired(true)),
	async execute(client, interaction) {

    const { adminRoleId } = require("../config.json")
    const { loadingEmoji, successEmoji } = require("../emojis.json")
    const adminRole = interaction.guild.roles.cache.find(role => role.id === adminRoleId);

    if (!adminRole)
    return console.log("[WARN] The Admin role does not exist!");

    if (!interaction.member.roles.cache.has(adminRole.id)) { interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Administrator role to use this command! \n__**Required role:**__ <@&${adminRole.id}>`, ephemeral: true })

    } else {

    const target = interaction.options.getUser('user');

    db.delete(`Warnings_${interaction.guild.id}_${target.id}`);
    db.delete(`Warn_SPAM_${interaction.guild.id}_${target.id}`);
    db.delete(`Warn_SWEAR_${interaction.guild.id}_${target.id}`);
    db.delete(`Warn_BEG_${interaction.guild.id}_${target.id}`);
    db.delete(`Warn_INSULT_${interaction.guild.id}_${target.id}`);
    db.delete(`Warn_BYP_${interaction.guild.id}_${target.id}`);

    interaction.reply({content: `${loadingEmoji} **Deleting ${target} (\`${target.id}\`)'s Warnings from DataBase...**`, ephemeral: true });

    let embed = new MessageEmbed()
      .setColor("GREEN")
      .setDescription(`${target}'s warnings has been **deleted.** | \`${target.id}\``);

    let time = "3s";
    setTimeout(function () {
      interaction.editReply(`${successEmoji} **Success!** ${target} is now having __**\`0\`**__ Warnings.`);
      interaction.channel.send({ embeds: [embed] });
    }, ms(time));

    }
	},
};