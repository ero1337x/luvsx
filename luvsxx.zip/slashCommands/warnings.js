const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js");
const db = require("quick.db");
const ms = module.require("ms");

module.exports = {
	data: new SlashCommandBuilder()
		.setName('warnings')
		.setDescription('Check your total warnings or other users warnings...')
    .addUserOption(option => option.setName('user').setDescription('The User to check their warnings.').setRequired(true)),
	async execute(client, interaction) {

    const { loadingEmoji, successEmoji } = require("../emojis.json")

    const target = interaction.options.getUser('user');

    let Warnings = client.db.get(
      `Warnings_${interaction.guild.id}_${target.id}`
    );

    let embed = new MessageEmbed()
      .setAuthor(`User's Warnings on ${interaction.guild.name}:`)
      .setDescription(`**Mentioned User:**\n${target}`)
      .addFields(
        { name: "• __Total Warnings:__", value: `\`${Warnings || "[No Warnings]"}\``, inline: true},
      )
      .setThumbnail(target.displayAvatarURL())
      .setColor("RED")
      .setTimestamp();

    let msg = interaction.reply({ content: `**${loadingEmoji} Loading ${target}'s punishments from DataBase...**\n\nDo not dismiss this message!`, ephemeral: true})

    //let msg = await interaction.channel.send({ embeds: [embed] });

    let time = "3s";
      setTimeout(function () {
        interaction.editReply({ content: `${successEmoji} **Success!**`, embeds: [embed] });
    }, ms(time));
    
    let time2 = "5s";
      setTimeout(function () {
        interaction.editReply({ content: `** **`, embeds: [embed] });
    }, ms(time2));

	},
};