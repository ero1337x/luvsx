const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js")

module.exports = {
	data: new SlashCommandBuilder()
		.setName('stop')
		.setDescription('Stop the Bot. [Only for Emergencies]')
    .addStringOption(option =>
		option.setName('checking')
			.setDescription('Are you sure about shutting down the bot?')
			//.setRequired(true)
      .addChoice('Yes', 'Yes')
      .addChoice('No', 'No')),
	async execute(client, interaction) {

    const value = interaction.options.getString('checking');

    const { adminRoleId } = require("../config.json")
    const { errorEmoji, successEmoji } = require("../emojis.json")
    const adminRole = interaction.guild.roles.cache.find(role => role.id === adminRoleId);

    if (!adminRole)
    return console.log("[WARN] The Admin role does not exist!");

    if (!interaction.member.roles.cache.has(adminRole.id)) { interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Administrator role to use this command! \n__**Required role:**__ <@&${adminRole.id}>`, ephemeral: true })

    } else {

      if(!value){
      await interaction.reply({ content: `${errorEmoji} Are you sure About that? Use **YES** or **NO.**`, ephemeral: true })
      }

      if(value === "Yes"){
        interaction.reply({ content: `${successEmoji} **Bot has been Shutted Down.**`, ephemeral: true })
        interaction.channel.send({ content: "👋 Good Bye World!"}).then(() => process.exit())
      } else {
        interaction.reply({ content: `${successEmoji} **Bot is not going to Shut Down.**`, ephemeral: true })
      }

    }
	},
};