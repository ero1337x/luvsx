const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");

module.exports = {
	data: new SlashCommandBuilder()
		.setName('invite')
		.setDescription('Invite the bot!'),
	async execute(client, interaction) {

    const { moderatorRoleId, clientName } = require("../config.json")
    const { successEmoji } = require("../emojis.json")
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
    return console.log("[WARN] The Mods role does not exist!");

    if (!interaction.member.roles.cache.has(modRole.id)) { interaction.reply({ content: `\`⛔\` **Missing Permissions:**\n\nYou do not have the Moderator role to use this command! \n__**Required role:**__ <@&${modRole.id}>`, ephemeral: true })

    } else {

      const embed = new MessageEmbed()
        .setAuthor(`${clientName} - Invite Me!`)
        .setDescription("You can invite me by clicking on the button below!")
        .setColor("GREEN")
        .setTimestamp()

      const row = new MessageActionRow()
			.addComponents(
				new MessageButton()
          .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=applications.commands%20bot`)
					.setLabel(`Invite The Bot`)
          .setEmoji("948948438601592862")
					.setStyle('LINK')
          .setDisabled(true), // Disabled because T.F.A's Tools is private bot.
			);

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true })

    }
	},
};