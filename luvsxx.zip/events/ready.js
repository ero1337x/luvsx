const pogger = require("pogger");
const colors = require("colors");
const { guildId, clientId, botActivity } = require("../config.json")

module.exports = async (client) => {
    	pogger.success('[CLIENT]'.bgCyan,`${client.user.tag} is Ready!`.green);
   client.user.setPresence({ activities: [{ name: botActivity, type: 'LISTENING' }], status: 'dnd' });

if(guildId === "" || null){
      
  pogger.error(`[CRASH]`.bgRed, `Guild ID is Required for Slash Commands Handler!`.underline.red);
  pogger.error(`[CRASH]`.bgRed, `Missing Value in: ./config.json => "guildId": ""`.red);
  pogger.error(`[CRASH]`.bgRed, `Repl.it has been Stopped.`.red), process.exit();

  } else {

     if(clientId === "" || null){
      
        pogger.error(`[CRASH]`.bgRed, `Client ID is Required for Slash Commands Handler!`.underline.red);
        pogger.error(`[CRASH]`.bgRed, `Missing Value in: ./config.json => "clientId": ""`.red);
        pogger.error(`[CRASH]`.bgRed, `Repl.it has been Stopped.`.red), process.exit();

  }
}
};
pogger.debug("[EVENTS]".bgYellow, "Loaded new Event: ready.js".underline.bold.cyan)