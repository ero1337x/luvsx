const pogger = require("pogger");
const colors = require("colors");
const { MessageEmbed } = require("discord.js");
const { clientName, developerTag } = require("../config.json");

module.exports = async (client, message) => {
  if (message.channel.type === "dm") return;
  if (message.author.bot) return;
  if (!message.guild) return;
  if (!message.member)
    message.member = await message.guild.fetchMember(message);

  if (message.content.match(new RegExp(`^<@!?${client.user.id}>`))) {

    const embed = new MessageEmbed()
      .setTitle(`${clientName} - Get Started:`)
      .addFields(
        { name: "Client ID:", value: `\`${client.user.id}\``, inline: true},
        { name: "Prefix:", value: `\`/\` (Slash Commands)`, inline: true},
        { name: "Developer:", value: `${developerTag}`, inline: true},
      )
      .setFooter(`Requested By: ${message.author.tag}`)
    
    return message.reply({ embeds: [embed] })
  }  
};
pogger.debug("[EVENTS]".bgYellow, "Loaded new Event: messageCreate.js".underline.bold.cyan)